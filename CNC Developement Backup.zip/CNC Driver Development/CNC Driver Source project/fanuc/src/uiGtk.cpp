#include <gtk/gtk.h>
 
static int counter = 0;
 
void greet( GtkWidget *widget, gpointer   data )
{
   // printf equivalent in GTK+
   g_print ("Hi there! Welcome to GTK\n");
   g_print ("%s clicked %d times\n",
      (char*)data, ++counter);
   g_print ("%s ip address %d times\n",
      (char*)data, ++counter);
  
}
 
void destroy( GtkWidget *widget,gpointer   data )
{
   gtk_main_quit ();
}
 
int main( int   argc,char *argv[] )
{
 
   GtkWidget *window;
   GtkWidget *button,*label,*label1,*label2,*table,*entry,*entry1,*entry2;
   gtk_init (&argc, &argv);
 
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
 
   g_signal_connect (window, "destroy",
   G_CALLBACK (destroy), NULL);
   /* Let's set the border width of the window to 20.
    * You may play with the value and see the
    * difference. */
   gtk_container_set_border_width
      (GTK_CONTAINER (window), 200);
 
   


   /* Create a 1x2 table */
   table = gtk_table_new (4, 2, TRUE);
   gtk_container_add (GTK_CONTAINER (window), table);


  /* create a new label. */
  label = gtk_label_new ("Enter CNC IP Address:" );
 // gtk_misc_set_alignment (GTK_MISC (label), 0, 0);
  gtk_table_set_homogeneous(GTK_TABLE (table), TRUE);
  gtk_table_attach_defaults (GTK_TABLE (table), label, 0, 1, 0, 1);
  label1 = gtk_label_new ("Port No:" );
  //gtk_misc_set_alignment (GTK_MISC (label1), 1, 0);
  gtk_table_set_homogeneous(GTK_TABLE (table), TRUE);
  gtk_table_attach_defaults (GTK_TABLE (table), label1, 0, 1, 0, 2);
  label2 = gtk_label_new ("Time Out Secs:" );
  //gtk_misc_set_alignment (GTK_MISC (label2), 2, 0);
  gtk_table_set_homogeneous(GTK_TABLE (table), TRUE);
  gtk_table_attach_defaults (GTK_TABLE (table), label2, 0, 1, 0, 3);

  

  //create a text box
  entry = gtk_entry_new ();
  gtk_entry_set_max_length (GTK_ENTRY (entry),0);
  gtk_table_attach_defaults (GTK_TABLE (table), entry, 1, 2, 0, 1);
  entry1 = gtk_entry_new ();
  gtk_entry_set_max_length (GTK_ENTRY (entry1),0);
  gtk_table_attach_defaults (GTK_TABLE (table), entry1, 1, 2, 0, 2);
  entry2 = gtk_entry_new ();
  gtk_entry_set_max_length (GTK_ENTRY (entry2),0);
  gtk_table_attach_defaults (GTK_TABLE (table), entry2, 1, 2, 0, 3);


   button = gtk_button_new_with_label ("Click Me!");
 
   g_signal_connect (GTK_OBJECT(button),"clicked",G_CALLBACK (greet),entry);
   gtk_text_set_editable(entry, TRUE);
   gtk_signal_connect(GTK_OBJECT(entry), "changed", GTK_SIGNAL_FUNC(greet), (GtkEditable*)entry);
 
   gtk_entry_set_max_length (GTK_ENTRY (button),0);
   gtk_table_attach_defaults (GTK_TABLE (table), button, 1, 2, 0, 4);
   //gtk_container_add (GTK_CONTAINER (window), button);
 
   gtk_widget_show_all(window); 
 
   gtk_main ();
 
   return 0;
}