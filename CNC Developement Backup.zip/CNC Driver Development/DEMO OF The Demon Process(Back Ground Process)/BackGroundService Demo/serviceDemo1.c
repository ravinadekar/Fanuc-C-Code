#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>

int main(void) {

   	FILE *fp = NULL;
        /* Our process ID and Session ID */
        pid_t pid = 0, sid = 0;

        /* Fork off the parent process */
        pid = fork();
        if (pid < 0) {
                printf("I Failed to create the process");
                exit(EXIT_FAILURE);
        }
        /* If we got a good PID, then
           we can exit the parent process. */
        if (pid > 0) {
		printf("I geetting the processID %d \n",pid);
                exit(EXIT_SUCCESS);
        }

        /* Change the file mode mask */
        umask(0); // about the file permission

        /* Open any logs here */        

        /* Create a new SID for the child process */
        sid = setsid();
        if (sid < 0) {
                /* Log the failure */
                exit(EXIT_FAILURE);
        }



        /* Change the current working directory */
        if ((chdir("../demodir")) < 0) {
                /* Log the failure */
                exit(EXIT_FAILURE);
        }

        /* Close out the standard file descriptors */
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
	
	fp = fopen("report1.txt","w");
        /* Daemon-specific initialization goes here */

        /* The Big Loop */
        while (1) {
           /* Do some task here ... */
	   
           sleep(5); /* wait 5 seconds */
	   fprintf(fp,"Hello Demo.... \n");
	   fflush(fp);

        }
   fclose(fp);
   exit(EXIT_SUCCESS);
}

